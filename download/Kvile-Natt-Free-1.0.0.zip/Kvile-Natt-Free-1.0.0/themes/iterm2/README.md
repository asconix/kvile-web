# Kvile for iTerm2

Color that lets your eyes rest. Free edition: **Kvile Natt** (night).

## Install

1. Open Settings > Profiles > Colors > Color Presets... > Import and choose the `.itermcolors` files in `themes/`. Or double-click a file, or run `open themes/kvile-natt.itermcolors`.
2. Pick Kvile Natt from the same **Color Presets...** menu.


Generated from `dist/tokens.json`. Do not edit the theme files by hand.

Copyright 2026 Christoph Pilka.

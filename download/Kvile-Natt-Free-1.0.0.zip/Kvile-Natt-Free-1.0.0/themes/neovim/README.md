# Kvile Natt for Neovim

Color that lets your eyes rest. Free edition: **Kvile Natt** (night). Neovim 0.9 or newer.

Covers the editor UI, Tree-sitter captures, LSP semantic tokens, diagnostics, diffs and git signs, plus Telescope,
nvim-cmp and blink.cmp, nvim-tree and neo-tree, which-key, indent guides, lazy.nvim, Mason, flash, Trouble, Noice
and more. A matching lualine theme is included.

## Install

Copy the contents of `themes/` (the `colors/` and `lua/` folders) into `~/.config/nvim/`, then:

```vim
:colorscheme kvile-natt
```

With lazy.nvim, point `dir` at the `themes` folder of this package:

```lua
{
  dir = "/path/to/Kvile-Natt-Free/themes/neovim/themes",
  name = "kvile",
  lazy = false,
  priority = 1000,
  config = function()
    require("kvile").setup({ transparent = false, italic_comments = true })
    vim.cmd.colorscheme("kvile-natt")
  end,
}
```

## Options

| Option | Default | |
|---|---|---|
| `transparent` | `false` | Keep your terminal's background |
| `italic_comments` | `true` | |
| `terminal_colors` | `true` | Set the `:terminal` ANSI palette |
| `on_highlights` | `nil` | `function(hl, palette)` to adjust any group |

lualine: `require("lualine").setup({ options = { theme = "kvile" } })`.

## Font

We recommend **JetBrains Mono** at **14 pt** (free: https://www.jetbrains.com/lp/mono/ or `brew install --cask font-jetbrains-mono`). In a terminal, set it in the terminal; in a GUI such as Neovide: `vim.o.guifont = "JetBrains Mono:h14"`.

Copyright 2026 Christoph Pilka.

-- Kvile. Copyright 2026 Christoph Pilka.
-- Generated from dist/tokens.json by generate-nvim.mjs. Edit the generator, not this file.
-- "kvile" is the default variant (Natt).
require("kvile").load("natt")

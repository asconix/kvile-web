-- Kvile. Copyright 2026 Christoph Pilka.
-- Generated from dist/tokens.json by generate-nvim.mjs. Edit the generator, not this file.

local M = {}

M.options = {
  transparent = false,      -- keep the terminal's own background
  italic_comments = true,
  terminal_colors = true,   -- set the :terminal ANSI palette
  on_highlights = nil,      -- function(hl, palette) to tweak any group
}

local names = { "natt" }

function M.setup(opts)
  M.options = vim.tbl_deep_extend("force", M.options, opts or {})
end

--- Load the variant: "natt".
function M.load(variant)
  local palettes = require("kvile.palette")
  local c = palettes[variant]
  if not c then
    vim.notify("kvile: unknown variant '" .. tostring(variant) .. "' (use " .. table.concat(names, ", ") .. ")", vim.log.levels.ERROR)
    return
  end
  if vim.g.colors_name then vim.cmd("hi clear") end
  if vim.fn.exists("syntax_on") == 1 then vim.cmd("syntax reset") end
  vim.o.termguicolors = true
  vim.o.background = c.mode
  vim.g.colors_name = "kvile-" .. variant

  local hl = require("kvile.theme").build(c, M.options)
  if M.options.on_highlights then M.options.on_highlights(hl, c) end
  for group, spec in pairs(hl) do
    vim.api.nvim_set_hl(0, group, spec)
  end

  if M.options.terminal_colors then
    local t = { c.black, c.red, c.green, c.yellow, c.blue, c.magenta, c.cyan, c.white,
                c.bright_black, c.bright_red, c.bright_green, c.bright_yellow,
                c.bright_blue, c.bright_magenta, c.bright_cyan, c.bright_white }
    for i, color in ipairs(t) do vim.g["terminal_color_" .. (i - 1)] = color end
  end
end

M.variants = names
M.palette = function(variant) return require("kvile.palette")[variant] end

return M

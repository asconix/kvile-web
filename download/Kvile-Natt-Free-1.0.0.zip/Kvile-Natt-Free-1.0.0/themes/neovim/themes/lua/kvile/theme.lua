-- Kvile. Copyright 2026 Christoph Pilka.
-- Generated from dist/tokens.json by generate-nvim.mjs. Edit the generator, not this file.

-- Builds the highlight table for one palette.
local M = {}

function M.build(c, o)
  o = o or {}
  local none = "NONE"
  local bg = o.transparent and none or c.bg
  local sidebar = o.transparent and none or c.surface
  local it = o.italic_comments ~= false
  local hl = {}

  -- ---------------------------------------------------------------- editor
  hl.Normal = { fg = c.fg, bg = bg }
  hl.NormalNC = { fg = c.fg, bg = bg }
  hl.NormalFloat = { fg = c.fg, bg = c.surface }
  hl.FloatBorder = { fg = c.border, bg = c.surface }
  hl.FloatTitle = { fg = c.func, bg = c.surface, bold = true }
  hl.Cursor = { fg = c.bg, bg = c.fg }
  hl.lCursor = { link = "Cursor" }
  hl.CursorIM = { link = "Cursor" }
  hl.TermCursor = { link = "Cursor" }
  hl.CursorLine = { bg = c.surface }
  hl.CursorColumn = { bg = c.surface }
  hl.ColorColumn = { bg = c.surface }
  hl.CursorLineNr = { fg = c.fg, bold = true }
  hl.LineNr = { fg = c.comment }
  hl.SignColumn = { fg = c.comment, bg = bg }
  hl.FoldColumn = { fg = c.comment, bg = bg }
  hl.Folded = { fg = c.muted, bg = c.raised }
  hl.EndOfBuffer = { fg = bg }
  hl.NonText = { fg = c.border }
  hl.Whitespace = { fg = c.border }
  hl.SpecialKey = { fg = c.border }
  hl.Conceal = { fg = c.comment }
  hl.VertSplit = { fg = c.border }
  hl.WinSeparator = { fg = c.border }
  hl.Visual = { bg = c.selection }
  hl.VisualNOS = { bg = c.selection }
  hl.Search = { bg = c.selection, fg = c.fg, underline = true }
  hl.IncSearch = { bg = c.func, fg = c.bg }
  hl.CurSearch = { bg = c.func, fg = c.bg }
  hl.Substitute = { bg = c.number, fg = c.bg }
  hl.MatchParen = { bg = c.selection, bold = true }
  hl.Directory = { fg = c.func }
  hl.Title = { fg = c.func, bold = true }
  hl.ErrorMsg = { fg = c.err }
  hl.WarningMsg = { fg = c.warn }
  hl.ModeMsg = { fg = c.fg, bold = true }
  hl.MoreMsg = { fg = c.ok }
  hl.Question = { fg = c.type }
  hl.MsgArea = { fg = c.fg }
  hl.WildMenu = { bg = c.selection }
  hl.Pmenu = { fg = c.fg, bg = c.surface }
  hl.PmenuSel = { bg = c.selection }
  hl.PmenuSbar = { bg = c.raised }
  hl.PmenuThumb = { bg = c.comment }
  hl.StatusLine = { fg = c.fg, bg = c.raised }
  hl.StatusLineNC = { fg = c.comment, bg = c.surface }
  hl.TabLine = { fg = c.comment, bg = c.surface }
  hl.TabLineFill = { bg = c.surface }
  hl.TabLineSel = { fg = c.fg, bg = c.bg, bold = true }
  hl.WinBar = { fg = c.muted, bg = bg }
  hl.WinBarNC = { fg = c.comment, bg = bg }
  hl.QuickFixLine = { bg = c.selection }
  hl.SpellBad = { sp = c.err, undercurl = true }
  hl.SpellCap = { sp = c.warn, undercurl = true }
  hl.SpellLocal = { sp = c.info, undercurl = true }
  hl.SpellRare = { sp = c.special, undercurl = true }

  -- ---------------------------------------------------------------- syntax (vim)
  hl.Comment = { fg = c.comment, italic = it }
  hl.Constant = { fg = c.constant }
  hl.String = { fg = c.string }
  hl.Character = { fg = c.string }
  hl.Number = { fg = c.number }
  hl.Boolean = { fg = c.constant }
  hl.Float = { fg = c.number }
  hl.Identifier = { fg = c.fg }
  hl.Function = { fg = c.func }
  hl.Statement = { fg = c.keyword }
  hl.Conditional = { fg = c.keyword }
  hl.Repeat = { fg = c.keyword }
  hl.Label = { fg = c.keyword }
  hl.Operator = { fg = c.muted }
  hl.Keyword = { fg = c.keyword }
  hl.Exception = { fg = c.keyword }
  hl.PreProc = { fg = c.special }
  hl.Include = { fg = c.keyword }
  hl.Define = { fg = c.keyword }
  hl.Macro = { fg = c.special }
  hl.PreCondit = { fg = c.special }
  hl.Type = { fg = c.type }
  hl.StorageClass = { fg = c.keyword }
  hl.Structure = { fg = c.type }
  hl.Typedef = { fg = c.type }
  hl.Special = { fg = c.special }
  hl.SpecialChar = { fg = c.special }
  hl.Tag = { fg = c.func }
  hl.Delimiter = { fg = c.muted }
  hl.SpecialComment = { fg = c.comment, bold = true }
  hl.Debug = { fg = c.special }
  hl.Underlined = { underline = true }
  hl.Bold = { bold = true }
  hl.Italic = { italic = true }
  hl.Ignore = { fg = c.comment }
  hl.Error = { fg = c.err }
  hl.Todo = { fg = c.bg, bg = c.info, bold = true }

  -- ---------------------------------------------------------------- treesitter
  local ts = {
    ["@variable"] = { fg = c.fg },
    ["@variable.builtin"] = { fg = c.constant },
    ["@variable.parameter"] = { fg = c.fg },
    ["@variable.member"] = { fg = c.fg },
    ["@constant"] = { fg = c.constant },
    ["@constant.builtin"] = { fg = c.constant },
    ["@constant.macro"] = { fg = c.special },
    ["@module"] = { fg = c.type },
    ["@label"] = { fg = c.keyword },
    ["@string"] = { fg = c.string },
    ["@string.regexp"] = { fg = c.special },
    ["@string.escape"] = { fg = c.special },
    ["@string.special"] = { fg = c.special },
    ["@string.special.url"] = { fg = c.func, underline = true },
    ["@character"] = { fg = c.string },
    ["@boolean"] = { fg = c.constant },
    ["@number"] = { fg = c.number },
    ["@number.float"] = { fg = c.number },
    ["@type"] = { fg = c.type },
    ["@type.builtin"] = { fg = c.type },
    ["@type.definition"] = { fg = c.type },
    ["@attribute"] = { fg = c.special },
    ["@property"] = { fg = c.fg },
    ["@function"] = { fg = c.func },
    ["@function.builtin"] = { fg = c.func },
    ["@function.call"] = { fg = c.func },
    ["@function.macro"] = { fg = c.special },
    ["@function.method"] = { fg = c.func },
    ["@function.method.call"] = { fg = c.func },
    ["@constructor"] = { fg = c.type },
    ["@operator"] = { fg = c.muted },
    ["@keyword"] = { fg = c.keyword },
    ["@keyword.function"] = { fg = c.keyword },
    ["@keyword.operator"] = { fg = c.keyword },
    ["@keyword.return"] = { fg = c.keyword },
    ["@keyword.import"] = { fg = c.keyword },
    ["@keyword.exception"] = { fg = c.keyword },
    ["@punctuation.delimiter"] = { fg = c.muted },
    ["@punctuation.bracket"] = { fg = c.muted },
    ["@punctuation.special"] = { fg = c.special },
    ["@comment"] = { fg = c.comment, italic = it },
    ["@comment.documentation"] = { fg = c.comment, italic = it },
    ["@comment.error"] = { fg = c.bg, bg = c.err, bold = true },
    ["@comment.warning"] = { fg = c.bg, bg = c.warn, bold = true },
    ["@comment.todo"] = { fg = c.bg, bg = c.info, bold = true },
    ["@comment.note"] = { fg = c.bg, bg = c.ok, bold = true },
    ["@markup.strong"] = { bold = true },
    ["@markup.italic"] = { italic = true },
    ["@markup.strikethrough"] = { strikethrough = true },
    ["@markup.underline"] = { underline = true },
    ["@markup.heading"] = { fg = c.func, bold = true },
    ["@markup.heading.1"] = { fg = c.keyword, bold = true },
    ["@markup.heading.2"] = { fg = c.func, bold = true },
    ["@markup.heading.3"] = { fg = c.type, bold = true },
    ["@markup.heading.4"] = { fg = c.string, bold = true },
    ["@markup.link"] = { fg = c.func },
    ["@markup.link.label"] = { fg = c.func },
    ["@markup.link.url"] = { fg = c.func, underline = true },
    ["@markup.raw"] = { fg = c.string },
    ["@markup.list"] = { fg = c.special },
    ["@markup.quote"] = { fg = c.muted, italic = true },
    ["@diff.plus"] = { fg = c.ok },
    ["@diff.minus"] = { fg = c.err },
    ["@diff.delta"] = { fg = c.info },
    ["@tag"] = { fg = c.func },
    ["@tag.attribute"] = { fg = c.type },
    ["@tag.delimiter"] = { fg = c.muted },
  }
  for k, v in pairs(ts) do hl[k] = v end

  -- ---------------------------------------------------------------- LSP
  hl["@lsp.type.class"] = { link = "@type" }
  hl["@lsp.type.interface"] = { link = "@type" }
  hl["@lsp.type.enum"] = { link = "@type" }
  hl["@lsp.type.struct"] = { link = "@type" }
  hl["@lsp.type.typeParameter"] = { link = "@type" }
  hl["@lsp.type.namespace"] = { link = "@module" }
  hl["@lsp.type.function"] = { link = "@function" }
  hl["@lsp.type.method"] = { link = "@function.method" }
  hl["@lsp.type.macro"] = { link = "@function.macro" }
  hl["@lsp.type.decorator"] = { link = "@attribute" }
  hl["@lsp.type.property"] = { link = "@property" }
  hl["@lsp.type.enumMember"] = { link = "@constant" }
  hl["@lsp.type.parameter"] = { link = "@variable.parameter" }
  hl["@lsp.type.variable"] = {}
  hl["@lsp.typemod.variable.readonly"] = { link = "@constant" }
  hl["@lsp.typemod.variable.defaultLibrary"] = { link = "@variable.builtin" }
  hl["@lsp.typemod.function.defaultLibrary"] = { link = "@function.builtin" }
  hl.LspReferenceText = { bg = c.raised }
  hl.LspReferenceRead = { bg = c.raised }
  hl.LspReferenceWrite = { bg = c.raised, underline = true }
  hl.LspSignatureActiveParameter = { fg = c.number, bold = true }
  hl.LspInlayHint = { fg = c.comment, bg = c.surface }
  hl.LspCodeLens = { fg = c.comment }

  -- ---------------------------------------------------------------- diagnostics
  hl.DiagnosticError = { fg = c.err }
  hl.DiagnosticWarn = { fg = c.warn }
  hl.DiagnosticInfo = { fg = c.info }
  hl.DiagnosticHint = { fg = c.type }
  hl.DiagnosticOk = { fg = c.ok }
  hl.DiagnosticUnderlineError = { sp = c.err, undercurl = true }
  hl.DiagnosticUnderlineWarn = { sp = c.warn, undercurl = true }
  hl.DiagnosticUnderlineInfo = { sp = c.info, undercurl = true }
  hl.DiagnosticUnderlineHint = { sp = c.type, undercurl = true }
  hl.DiagnosticVirtualTextError = { fg = c.err }
  hl.DiagnosticVirtualTextWarn = { fg = c.warn }
  hl.DiagnosticVirtualTextInfo = { fg = c.info }
  hl.DiagnosticVirtualTextHint = { fg = c.type }
  hl.DiagnosticFloatingError = { fg = c.err }
  hl.DiagnosticFloatingWarn = { fg = c.warn }
  hl.DiagnosticFloatingInfo = { fg = c.info }
  hl.DiagnosticFloatingHint = { fg = c.type }
  hl.DiagnosticSignError = { fg = c.err, bg = bg }
  hl.DiagnosticSignWarn = { fg = c.warn, bg = bg }
  hl.DiagnosticSignInfo = { fg = c.info, bg = bg }
  hl.DiagnosticSignHint = { fg = c.type, bg = bg }
  hl.DiagnosticUnnecessary = { fg = c.comment }
  hl.DiagnosticDeprecated = { fg = c.comment, strikethrough = true }

  -- ---------------------------------------------------------------- diff and git
  hl.DiffAdd = { bg = c.diff_add }
  hl.DiffDelete = { bg = c.diff_del, fg = c.err }
  hl.DiffChange = { bg = c.diff_change }
  hl.DiffText = { bg = c.diff_text }
  hl.Added = { fg = c.ok }
  hl.Removed = { fg = c.err }
  hl.Changed = { fg = c.info }
  hl.diffAdded = { fg = c.ok }
  hl.diffRemoved = { fg = c.err }
  hl.diffChanged = { fg = c.info }
  hl.diffFile = { fg = c.func }
  hl.diffLine = { fg = c.comment }
  hl.GitSignsAdd = { fg = c.ok }
  hl.GitSignsChange = { fg = c.info }
  hl.GitSignsDelete = { fg = c.err }
  hl.GitSignsCurrentLineBlame = { fg = c.comment, italic = true }
  hl.GitSignsAddInline = { bg = c.diff_text }
  hl.GitSignsDeleteInline = { bg = c.diff_del }
  hl.DiffviewDiffAddAsDelete = { bg = c.diff_del }

  -- ---------------------------------------------------------------- plugins
  -- Telescope
  hl.TelescopeNormal = { fg = c.fg, bg = c.surface }
  hl.TelescopeBorder = { fg = c.border, bg = c.surface }
  hl.TelescopePromptNormal = { fg = c.fg, bg = c.raised }
  hl.TelescopePromptBorder = { fg = c.raised, bg = c.raised }
  hl.TelescopePromptTitle = { fg = c.bg, bg = c.func, bold = true }
  hl.TelescopePreviewTitle = { fg = c.bg, bg = c.ok, bold = true }
  hl.TelescopeResultsTitle = { fg = c.surface, bg = c.surface }
  hl.TelescopeSelection = { bg = c.selection }
  hl.TelescopeMatching = { fg = c.number, bold = true }
  hl.TelescopePromptPrefix = { fg = c.func }
  -- completion (nvim-cmp, blink.cmp)
  hl.CmpItemAbbr = { fg = c.fg }
  hl.CmpItemAbbrMatch = { fg = c.func, bold = true }
  hl.CmpItemAbbrMatchFuzzy = { fg = c.func }
  hl.CmpItemAbbrDeprecated = { fg = c.comment, strikethrough = true }
  hl.CmpItemMenu = { fg = c.comment }
  hl.CmpItemKind = { fg = c.type }
  hl.CmpItemKindFunction = { fg = c.func }
  hl.CmpItemKindMethod = { fg = c.func }
  hl.CmpItemKindKeyword = { fg = c.keyword }
  hl.CmpItemKindVariable = { fg = c.fg }
  hl.CmpItemKindSnippet = { fg = c.special }
  hl.BlinkCmpMenu = { link = "Pmenu" }
  hl.BlinkCmpMenuSelection = { link = "PmenuSel" }
  hl.BlinkCmpLabelMatch = { fg = c.func, bold = true }
  hl.BlinkCmpGhostText = { fg = c.comment }
  -- file trees
  hl.NvimTreeNormal = { fg = c.fg, bg = sidebar }
  hl.NvimTreeFolderName = { fg = c.func }
  hl.NvimTreeOpenedFolderName = { fg = c.func, bold = true }
  hl.NvimTreeRootFolder = { fg = c.keyword, bold = true }
  hl.NvimTreeIndentMarker = { fg = c.border }
  hl.NvimTreeGitDirty = { fg = c.info }
  hl.NvimTreeGitNew = { fg = c.ok }
  hl.NvimTreeGitDeleted = { fg = c.err }
  hl.NeoTreeNormal = { fg = c.fg, bg = sidebar }
  hl.NeoTreeNormalNC = { fg = c.fg, bg = sidebar }
  hl.NeoTreeDirectoryName = { fg = c.func }
  hl.NeoTreeDirectoryIcon = { fg = c.func }
  hl.NeoTreeRootName = { fg = c.keyword, bold = true }
  hl.NeoTreeIndentMarker = { fg = c.border }
  hl.NeoTreeGitModified = { fg = c.info }
  hl.NeoTreeGitAdded = { fg = c.ok }
  hl.NeoTreeGitDeleted = { fg = c.err }
  hl.NeoTreeGitUntracked = { fg = c.special }
  hl.NeoTreeDotfile = { fg = c.comment }
  -- misc
  hl.WhichKey = { fg = c.func }
  hl.WhichKeyGroup = { fg = c.keyword }
  hl.WhichKeyDesc = { fg = c.fg }
  hl.WhichKeySeparator = { fg = c.comment }
  hl.WhichKeyNormal = { bg = c.surface }
  hl.IblIndent = { fg = c.border }
  hl.IblScope = { fg = c.comment }
  hl.IndentBlanklineChar = { fg = c.border }
  hl.IndentBlanklineContextChar = { fg = c.comment }
  hl.LazyH1 = { fg = c.bg, bg = c.func, bold = true }
  hl.LazyButton = { bg = c.raised }
  hl.LazyButtonActive = { fg = c.bg, bg = c.keyword }
  hl.LazySpecial = { fg = c.special }
  hl.MasonHeader = { fg = c.bg, bg = c.func, bold = true }
  hl.MasonHighlight = { fg = c.type }
  hl.MasonHighlightBlock = { fg = c.bg, bg = c.type }
  hl.MiniStatuslineModeNormal = { fg = c.bg, bg = c.func, bold = true }
  hl.MiniStatuslineModeInsert = { fg = c.bg, bg = c.string, bold = true }
  hl.MiniStatuslineModeVisual = { fg = c.bg, bg = c.keyword, bold = true }
  hl.MiniStatuslineModeReplace = { fg = c.bg, bg = c.err, bold = true }
  hl.MiniStatuslineModeCommand = { fg = c.bg, bg = c.number, bold = true }
  hl.MiniIndentscopeSymbol = { fg = c.comment }
  hl.MiniCursorword = { bg = c.raised }
  hl.FlashLabel = { fg = c.bg, bg = c.number, bold = true }
  hl.FlashMatch = { fg = c.fg, bg = c.selection }
  hl.FlashCurrent = { fg = c.bg, bg = c.func }
  hl.HopNextKey = { fg = c.number, bold = true }
  hl.HopNextKey1 = { fg = c.type, bold = true }
  hl.HopNextKey2 = { fg = c.func }
  hl.HopUnmatched = { fg = c.comment }
  hl.NoiceCmdlinePopupBorder = { fg = c.func }
  hl.NotifyBackground = { bg = c.surface }
  hl.TroubleNormal = { fg = c.fg, bg = sidebar }
  hl.TodoBgTODO = { fg = c.bg, bg = c.info, bold = true }
  hl.TodoBgFIX = { fg = c.bg, bg = c.err, bold = true }
  hl.TodoBgWARN = { fg = c.bg, bg = c.warn, bold = true }
  hl.RainbowDelimiterRed = { fg = c.err }
  hl.RainbowDelimiterYellow = { fg = c.constant }
  hl.RainbowDelimiterBlue = { fg = c.func }
  hl.RainbowDelimiterOrange = { fg = c.number }
  hl.RainbowDelimiterGreen = { fg = c.string }
  hl.RainbowDelimiterViolet = { fg = c.keyword }
  hl.RainbowDelimiterCyan = { fg = c.type }
  hl.OilDir = { fg = c.func }
  hl.OilDirIcon = { fg = c.func }
  hl.AlphaHeader = { fg = c.keyword }
  hl.DashboardHeader = { fg = c.keyword }

  return hl
end

return M

-- Kvile. Copyright 2026 Christoph Pilka.
-- Generated from dist/tokens.json by generate-nvim.mjs. Edit the generator, not this file.

local function theme(p)
  local function mode(color)
    return {
      a = { fg = p.bg, bg = color, gui = "bold" },
      b = { fg = p.fg, bg = p.raised },
      c = { fg = p.muted, bg = p.surface },
    }
  end
  return {
    normal = mode(p.func),
    insert = mode(p.string),
    visual = mode(p.keyword),
    replace = mode(p.err),
    command = mode(p.number),
    terminal = mode(p.type),
    inactive = {
      a = { fg = p.comment, bg = p.surface },
      b = { fg = p.comment, bg = p.surface },
      c = { fg = p.comment, bg = p.surface },
    },
  }
end

-- Follows the loaded colorscheme: kvile-natt.
local name = (vim.g.colors_name or "kvile-natt"):gsub("^kvile%-?", "")
if name == "" then name = "natt" end
return theme(require("kvile.palette")[name] or require("kvile.palette").natt)

# Kvile for Terminal (macOS)

Color that lets your eyes rest. Free edition: **Kvile Natt** (night).

## Install

1. Double-click a `.terminal` file in `themes/` (or `open themes/kvile-natt.terminal`). Terminal imports it as a new profile.
2. Open Terminal > Settings > Profiles, select the Kvile profile and click **Default** to use it for new windows.


Generated from `dist/tokens.json`. Do not edit the theme files by hand.

Copyright 2026 Christoph Pilka.

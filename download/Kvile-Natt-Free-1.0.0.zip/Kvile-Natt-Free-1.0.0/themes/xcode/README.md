# Kvile for Xcode

Color that lets your eyes rest. Free edition: **Kvile Natt** (night).

Source editor and debug console colors. Syntax roles match the other Kvile themes: keywords violet, strings green,
functions blue, types cyan, numbers orange, constants yellow, attributes and preprocessor pink.

## Install

1. Copy the theme files (the names contain a space, so keep the quotes):
   ```sh
   mkdir -p ~/Library/Developer/Xcode/UserData/FontAndColorThemes
   cp themes/*.xccolortheme ~/Library/Developer/Xcode/UserData/FontAndColorThemes/
   ```
2. Quit and reopen Xcode.
3. Open Xcode > Settings > Themes and pick **Kvile Natt**.

## Font

We recommend **JetBrains Mono** at **14 pt**. It is free: download it from https://www.jetbrains.com/lp/mono/ or on macOS run `brew install --cask font-jetbrains-mono`.

The Kvile themes already use JetBrains Mono at 14 pt. If it is not installed, Xcode falls back to another font, so install it first (command above) and restart Xcode. You can change the font or size in the same Themes pane; the colors stay.

Generated from `dist/tokens.json` by `node generate-xcode.mjs`. Do not edit the theme files by hand.

Copyright 2026 Christoph Pilka.

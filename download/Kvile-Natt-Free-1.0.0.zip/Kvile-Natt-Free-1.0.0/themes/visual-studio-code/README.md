# Kvile Natt for VS Code

Color that lets your eyes rest. Free edition: **Kvile Natt** (night).

## Install

Copy this folder into your extensions directory, then restart VS Code and pick **Preferences: Color Theme > Kvile Natt**:

```sh
cp -R . ~/.vscode/extensions/asconix.kvile-natt-0.1.0
```

(On Windows the folder is `%USERPROFILE%\.vscode\extensions`.) Or package it with `npx @vscode/vsce package` and install the `.vsix` with **Extensions: Install from VSIX**.

Copyright 2026 Christoph Pilka.

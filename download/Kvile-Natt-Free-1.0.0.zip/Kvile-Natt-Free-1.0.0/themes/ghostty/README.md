# Kvile for Ghostty

Color that lets your eyes rest. Free edition: **Kvile Natt** (night).

## Install

1. Copy the theme files:
   ```sh
   mkdir -p ~/.config/ghostty/themes
   cp themes/kvile-natt ~/.config/ghostty/themes/
   ```
2. In `~/.config/ghostty/config` set `theme = kvile-natt`.
3. Reload the config (`Cmd+Shift+,` on macOS, `Ctrl+Shift+,` on Linux).


[rootshell](https://www.rootshell.com) (the iOS/iPadOS/visionOS/Mac terminal) reads this same Ghostty theme format: in rootshell, open Settings > Themes and import one of the files above directly, no conversion needed.

Generated from `dist/tokens.json`. Do not edit the theme files by hand.

Copyright 2026 Christoph Pilka.

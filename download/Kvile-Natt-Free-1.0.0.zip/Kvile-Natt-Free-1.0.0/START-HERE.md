# Kvile Natt, free edition 1.0.0

Color that lets your eyes rest. Thank you for trying Kvile.

## What is in this package

- `themes/`: **Kvile Natt** (the night variant) for VS Code, Neovim, Terminal (macOS), iTerm2, Ghostty and Xcode. Each folder has its own install steps in its `README.md`.
- `wallpapers/`: the Natt wallpapers for desktop, phone and watch.
- `book/`: the e-book "Color for Screens" as PDF and EPUB.
- `LICENSE.txt`: the license terms for this free edition.

## Want more?

The full Kvile has all four variants (Natt, Skumring, Dag and Kontrast) for all 52 apps, plus wallpapers for every variant and every future update. Early bird price: https://kvile.dev
